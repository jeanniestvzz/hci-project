import StudentInformation from './StudentInformation';

export default StudentInformation;