import AddScienceElective from './AddScienceElective';

export default AddScienceElective;