import SwDropdown from './SwDropdown';

export default SwDropdown;