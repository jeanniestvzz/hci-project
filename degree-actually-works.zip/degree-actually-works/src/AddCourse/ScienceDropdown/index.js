import ScienceDropdown from './ScienceDropdown'

export default ScienceDropdown;