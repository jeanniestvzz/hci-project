import PastCourseInfo from './PastCourseInfo';

export default PastCourseInfo;