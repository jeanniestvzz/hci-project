import FutureCourseInfo from './FutureCourseInfo';

export default FutureCourseInfo;