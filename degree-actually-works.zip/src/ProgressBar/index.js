import DegreeProgressBar from './DegreeProgressBar';

export default DegreeProgressBar;