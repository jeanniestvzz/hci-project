import React, { useState,useEffect } from 'react';
import Button from 'react-bootstrap/Button';
import Modal from 'react-bootstrap/Modal';

function PastCourseInfo({shouldShow,hideModal}) {
  const [show, setShow] = useState(shouldShow);
  useEffect(() => {
    setShow(shouldShow)
  }, [shouldShow])
  
  const handleClose = () => hideModal();
  const handleShow = () => setShow(true);
  console.log(shouldShow)

  return (
    <>
    {false &&
      <Button variant="primary" onClick={handleShow}>
        Click to show past course description
      </Button>
    }
      <Modal
        show={show}
        onHide={handleClose}
        backdrop="static"
        keyboard={false}
      >
        <Modal.Header closeButton>
          <Modal.Title>
            Course Overview
          </Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <ul>
            <li>Date completed course</li>
            <li>Course code - Course title</li>
            <li>Credit Hours: ?</li>
            <li>Course description</li>
          </ul>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="primary" onClick={handleClose}>Done</Button>
        </Modal.Footer>
      </Modal>
    </>
  );
}

export default PastCourseInfo