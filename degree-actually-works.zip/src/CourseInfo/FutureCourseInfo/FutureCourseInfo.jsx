import React, { useState,useEffect } from 'react';
import Button from 'react-bootstrap/Button';
import Modal from 'react-bootstrap/Modal';

function FutureCourseInfo({shouldShow,hideModal}) {
  const [show, setShow] = useState(shouldShow);
  useEffect(() => {
    setShow(shouldShow)
  }, [shouldShow])
  
  const handleClose = () => hideModal();
  const handleShow = () => setShow(true);
  console.log(shouldShow)


  return (
    <>
      <Button variant="primary" onClick={handleShow}>
        Click to show future course description
      </Button>

      <Modal
        show={show}
        onHide={handleClose}
        backdrop="static"
        keyboard={false}
      >
        <Modal.Header closeButton>
          <Modal.Title>
            Upcoming Course Overview
          </Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <ul>
            <li>Course Code - Course Title</li>
            <li>Credit Hours: ?</li>
            <li>Course Description</li>
            <li>Course prerequisites, if any, with link to <a href="http://www.usf.edu/">prerequisite course overview</a></li>
          </ul>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="primary" onClick={handleClose}>Done</Button>
        </Modal.Footer>
      </Modal>
    </>
  );
}

export default FutureCourseInfo