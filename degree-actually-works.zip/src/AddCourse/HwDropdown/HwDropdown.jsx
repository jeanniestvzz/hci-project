import React from 'react';
import Dropdown from 'react-bootstrap/Dropdown';
import DropdownButton from 'react-bootstrap/DropdownButton';

function HwDropdown({hideModal}) {

  
  return (
    <DropdownButton id="dropdown-basic-button" title="Click to choose hardware elective">
      <form>
      <label>
      <table>
 
        <tr onClick={() => hideModal({"type1": "CDA 4203", "type2": "Computer System Design"})}><Dropdown.Item href="#/action-1"><td>CDA 4203</td><td>Computer System Design</td><td>3 hrs</td><td>Open Spring 23</td></Dropdown.Item></tr>
        <tr><Dropdown.Item href="#/action-2"><td>CDA 4213</td><td>CMOS-VLSI Design</td><td>3 hrs</td><td>Closed Spring 23</td></Dropdown.Item></tr>
        <tr><Dropdown.Item href="#/action-3"><td>CDA 4321</td><td>Cryptographic Hardware and Embedded Systems</td><td>3 hrs</td><td>Open Spring 23</td></Dropdown.Item></tr>
      </table>
      </label>
      </form>

    </DropdownButton>
  );
} 

export default HwDropdown