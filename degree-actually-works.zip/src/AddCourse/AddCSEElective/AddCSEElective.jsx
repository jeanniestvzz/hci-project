import React, { useState,useEffect } from 'react';
import Button from 'react-bootstrap/Button';
import Modal from 'react-bootstrap/Modal';
import HwDropdown from '../HwDropdown';
import SwDropdown from '../SwDropdown';
import TheDropdown from '../TheDropdown';

function AddCSEElective({shouldShow,hideModal}) {
  const [show, setShow] = useState(shouldShow);

  useEffect(() => {
    setShow(shouldShow)
  }, [shouldShow])
  
  const handleClose = () => hideModal();
  const handleShow = () => setShow(true);
  console.log(shouldShow)
  return (
    <>
    {false &&
      <Button variant="primary" onClick={handleShow}>
        Click to choose a CSE elective
      </Button>
    }

      <Modal
        show={show}
        onHide={handleClose}
        backdrop="static"
        keyboard={false}
      >
        <Modal.Header closeButton>
          <Modal.Title>CSE Electives</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <ul className='electiveDropdowns'>
            <li><HwDropdown hideModal={hideModal}/></li>
            <br />
            <li><SwDropdown hideModal={hideModal} /></li>
            <br />
            <li><TheDropdown hideModal={hideModal} /></li>
          </ul>       
        </Modal.Body>
        <Modal.Footer>
          <Button variant="primary" onClick={handleClose}>Close</Button>
        </Modal.Footer>
      </Modal>
    </>
  );
}

export default AddCSEElective;