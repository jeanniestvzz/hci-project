import React, { useState,useEffect } from 'react';
import Button from 'react-bootstrap/Button';
import Modal from 'react-bootstrap/Modal';
import SwDropdown from '../SwDropdown';


function AddSoftwareElective({shouldShow,hideSWModal}) {
  const [show, setShow] = useState(shouldShow);
  const [showCSE, setShowCSE] = useState(false)

  useEffect(() => {
    setShow(shouldShow)
  }, [shouldShow])

  const handleClose = () => hideSWModal();
  const handleShow = () => setShow(true);
  console.log(shouldShow)

  return (
    <>
      <Button variant="primary" onClick={handleShow}>
        Click to choose a software elective
      </Button>

      <Modal
        show={show}
        onHide={handleClose}
        backdrop="static"
        keyboard={false}
      >
        <Modal.Header closeButton>
          <Modal.Title>CSE Software Electives</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <SwDropdown hideSWModal={hideSWModal}/>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="primary" onClick={handleClose}>Close</Button>
        </Modal.Footer>
      </Modal>
    </>
  );
}

export default AddSoftwareElective;